Files contained:
3000userlogin.c -base file
3000userloginQ1.c - Q1 for part 1
3000userloginQ1.diff-Diff for 3000userloginQ1
3000userloginQ2.c - Q2 for part 1
3000userloginQ2.diff-Diff for 3000userloginQ2
3000shell.c - base file
3000shellQ1.c - Q1 for part 2
3000Q1.diff-Diff for 3000shellQ1
3000shellQ2.c - Q2 for part 2
3000Q2.diff-Diff for 3000shellQ2
3000shellBonus.c - bonus for part 2
3000shellBonus.diff - diff for bonus
Assignment2_written.txt - plaintext file containing written answers
